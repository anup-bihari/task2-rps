
var score = 0;
//var soundFilePath = "sound/beep.mp3";
var playerChoice;


var readable = {
  "0": "Rock",
  "1": "Paper",
  "2": "Scissors"
};

order = [0, 1, 2, 0];

var images = {
  items: document.getElementsByTagName('img'),
  init: function() {
    for (var pos = 0; pos < this.items.length; pos++) {
      this.items[pos].id = pos;
      this.items[pos].addEventListener("click", function() {
        assignClick(this.id);
        //playBeep(); // Plays beep sound on click
      });
    }
  }
};

/*function playBeep() {
  var beepAudio = new Audio(soundFilePath);
  beepAudio.play();
};*/

// Utility function to get a random integer number in a given range.
function randIntInRange(min, max) {
  return Math.floor(Math.random() * ((max-min) + 1));
};

var cpu = {
  // Get the CPU/Computer's choice randomly an integer between 0 and 2 inclusive.
  init: function() {
    this.cpuChoice = randIntInRange(0, 2);
    this.cpuText = "Computer -->" + readable[this.cpuChoice];
  },
  cpuChoice: 0,
  cpuText: ''
};


var chooseWinner = function(cpuChoice, playerChoice) {
  var text = "";
  if(cpuChoice == playerChoice) {
    text = "Tie";
  }
  else if(order[cpuChoice + 1] === order[playerChoice]) {
    score++;
    text = "Player  won";
  }
  else {
    score--;
    text = "Computer Won";
  }
  return text;
};



function assignClick(position) {
  playerChoice = position;

  // Cpu makes it's choice and result is displayed.
  cpu.init();
  console.log(playerChoice + " " + cpu.cpuChoice);
  var label = document.getElementById("label");
  label.innerHTML = "<p>" + cpu.cpuText + "<br>";
  label.innerHTML += chooseWinner(cpu.cpuChoice, playerChoice);
  label.innerHTML += "<br>" + "SCORE: " + score + "</p>";
};


images.init();
