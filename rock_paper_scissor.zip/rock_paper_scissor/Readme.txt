step1>
		Just run the index file to any browser.
		select any one
				rock paper or scissor 
		computer will automatically will choose any image at random.
step 2
		enjoy